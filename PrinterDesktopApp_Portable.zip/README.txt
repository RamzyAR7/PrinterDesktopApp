===============================================
 Printer Desktop App - Portable Version
===============================================

INSTALLATION INSTRUCTIONS:

1. Extract this ZIP file to any folder on your computer
2. Run "DesktopApp.exe" to start the application
3. Optionally, run "Install_Shortcuts.bat" to create desktop and start menu shortcuts

REQUIREMENTS:
- Windows 7 or later
- .NET Framework 4.8 or later

UNINSTALL:
Simply delete the extracted folder

For support, contact: [Your Contact Information]

